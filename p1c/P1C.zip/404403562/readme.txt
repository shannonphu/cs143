All of the project criteria was met in this project.

Shannon did the following:

Displaying tables for actor/movie/director tables 
Designing the User Interface of the Project
Creating the Navigation Bar of the Project 
Creating the Forms for inserting new Actors/Directors as well as movies 
Input validation for all input pages 

Jason did the following:

Creating the comment system
Creating the add actor/movie relation and add director/movie relation
Implementing the search functionality in the navigation bar 
Adding all the selenium test cases 
Wrote the readme 