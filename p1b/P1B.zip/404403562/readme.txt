Shannon worked on query.php in full and Jason worked on violate.sql in full.
We split the work between us two for create.sql, load.sql, queries.sql.